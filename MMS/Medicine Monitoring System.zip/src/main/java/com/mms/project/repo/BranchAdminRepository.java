package com.mms.project.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mms.project.model.BranchAdmin;

/**
 * 
 * 
 * @author palagiriharsh.reddy@hcl.com
 * 
 */

//BranchAdmin Repository

public interface BranchAdminRepository extends JpaRepository<BranchAdmin, Long>{

}
