package com.service.employeetraining.service;

import java.util.List;

import com.service.employeetraining.model.Employee;
import com.service.employeetraining.model.Training;

public interface TrainingEmployeeService { 
	
	public List<Training> getTrainingEmployee();
}
