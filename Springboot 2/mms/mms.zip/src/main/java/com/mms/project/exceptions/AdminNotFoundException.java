
package com.mms.project.exceptions;

//AdminNotFoundException class 
public class AdminNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
