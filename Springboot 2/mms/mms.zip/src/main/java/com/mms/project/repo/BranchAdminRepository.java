package com.mms.project.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mms.project.model.BranchAdmin;

/**
 * 
 * 
 * @author Team 1
 * 
 */

//BranchAdmin Repository

public interface BranchAdminRepository extends JpaRepository<BranchAdmin, Long>{

}
